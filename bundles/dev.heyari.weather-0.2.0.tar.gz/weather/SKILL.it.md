---
# `name` must match the directory (`weather/`) — it's the stable
# system identifier, not a display field. Per-locale display strings
# live in `description` (below) and the markdown body. Don't translate
# this.
name: weather
description: Meteo attuale, previsioni e condizioni come probabilità di pioggia, vento, umidità e UV — per la tua posizione attuale o per qualsiasi luogo tu indichi.
license: MIT
metadata:
  ari:
    id: dev.heyari.weather
    version: "0.2.0"
    author: Ari core team
    homepage: https://github.com/ari-digital-assistant/ari-skills
    engine: ">=0.3"
    capabilities: [http, location, storage_kv]
    languages: [en, it]
    specificity: high
    matching:
      # I pattern vengono confrontati con l'input POST-NORMALIZZATO: in minuscolo,
      # con le elisioni sostituite da uno spazio (`l'ora` → `l ora`) prima che
      # il motore applichi la regex. L'espansione delle contrazioni riguarda
      # solo l'inglese: per `it` la normalizzazione usa
      # `strip_italian_elisions`, non `expand_english_contractions`.
      # La normalizzazione NON rimuove gli accenti (`è`/`à` superano
      # il filtro `is_alphanumeric`, che riconosce i caratteri Unicode). Il motivo
      # di `piove(ra|rà)?` è un altro: gli utenti e i sistemi STT spesso omettono
      # l'accento durante la digitazione o la trascrizione, quindi il pattern copre
      # `piove`, `piovera` e `pioverà`.
      patterns:
        - regex: "\\b(tempo|meteo)\\b"
          weight: 0.95
        - regex: "\\bprevisioni\\b"
          weight: 0.9
        - regex: "\\bpiove(ra|rà)?\\b"
          weight: 0.9
        - regex: "\\b(vento|ventoso)\\b"
          weight: 0.75
        - regex: "\\b(raggi )?uv\\b"
          weight: 0.8
        - regex: "\\bumidit(a|à)\\b"
          weight: 0.8
      custom_score: false
    # Gli esempi portano `args` perché FunctionGemma impari a estrarre i
    # due slot: `location` (stringa vuota = usa il GPS) e `when`. I valori
    # di `when` restano i token INGLESI (now | today | tomorrow | this
    # week): il router della skill mappa quei token, e il modello impara
    # a emetterli dalle frasi italiane.
    examples:
      - text: "che tempo fa"
        args:
          location: ""
          when: "now"
      - text: "che tempo fa a tokyo"
        args:
          location: "tokyo"
          when: "now"
      - text: "meteo a roma domani"
        args:
          location: "roma"
          when: "tomorrow"
      - text: "previsioni per questa settimana"
        args:
          location: ""
          when: "this week"
      - text: "pioverà oggi"
        args:
          location: ""
          when: "today"
      - text: "c'è vento"
        args:
          location: ""
          when: "now"
      - text: "qual è l'indice uv"
        args:
          location: ""
          when: "now"
      - text: "c'è umidità oggi"
        args:
          location: ""
          when: "today"
      # Frasi oblique che i pattern qui sopra non intercettano di proposito:
      # sono quelle che il router vede davvero in produzione.
      - text: "mi serve il cappotto oggi"
        args:
          location: ""
          when: "today"
      - text: "quanto fa caldo fuori"
        args:
          location: ""
          when: "now"
      - text: "devo portare l'ombrello domani"
        args:
          location: ""
          when: "tomorrow"
      - text: "farà freddo a londra domani"
        args:
          location: "londra"
          when: "tomorrow"
      - text: "serve la crema solare oggi"
        args:
          location: ""
          when: "today"
      - text: "c'è il sole a valletta"
        args:
          location: "valletta"
          when: "now"
      - text: "nevicherà questa settimana"
        args:
          location: ""
          when: "this week"
      - text: "quanti gradi faranno domani"
        args:
          location: ""
          when: "tomorrow"
    settings:
      - key: units
        label: Unità
        type: select
        default: auto
        options:
          - value: auto
            label: Automatico
          - value: metric
            label: Metrico (°C, km/h)
          - value: imperial
            label: Imperiale (°F, mph)
    wasm:
      module: skill.wasm
      memory_limit_mb: 4
---

# Meteo

Condizioni attuali e previsioni, oltre a domande puntuali su vento,
probabilità di pioggia, umidità e indice UV. Chiedi che tempo fa dove ti
trovi — la skill usa una posizione approssimativa del dispositivo —
oppure indica un luogo qualsiasi ("meteo a tokyo").

Le condizioni attuali vengono riassunte con una frase principale, seguita
dai dettagli che meritano di essere detti: la probabilità di pioggia per
le ore restanti della giornata (con l'ora di punta, quando la pioggia si
concentra invece di cadere tutto il giorno), direzione e velocità del
vento, e umidità. In una giornata calma e asciutta resta solo la frase
principale.

## Frasi supportate

- `che tempo fa` — condizioni attuali, posizione corrente
- `che tempo fa a tokyo` — condizioni attuali, luogo indicato
- `meteo a roma domani` — luogo indicato, giorno successivo
- `previsioni per questa settimana` — panoramica su più giorni
- `pioverà oggi` — domanda sulle precipitazioni
- `c'e vento` — domanda sul vento, riferita al giorno richiesto
- `qual e l'indice uv` — domanda sull'indice UV
- `c'e umidità oggi` — domanda sull'umidità

## Argomenti estratti

Il router estrae due slot:

- `location` — il nome del luogo, oppure una stringa vuota per usare la
  posizione approssimativa del dispositivo tramite la capability
  `location`.
- `when` — uno tra `now`, `today`, `tomorrow` o `this week` (token
  inglesi). Predefinito a `now` quando la frase non contiene un orario.

## Impostazioni

- **Unità** — `Automatico` (segue la lingua del dispositivo), `Metrico`
  (°C, km/h), o `Imperiale` (°F, mph).

## Backend

Le previsioni provengono, tramite la capability `http`, da provider senza
chiave (Open-Meteo), con risultati memorizzati brevemente in cache tramite
`storage_kv` per evitare richieste ripetute all'API.
